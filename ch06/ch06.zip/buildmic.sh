icpc  -O3    -openmp -vec-report3  pciebw.cpp gettime.cpp -o pciebw.out
icpc  -O3    -openmp -vec-report3  pciebw-d2h.cpp gettime.cpp -o pciebw-d2h.out


